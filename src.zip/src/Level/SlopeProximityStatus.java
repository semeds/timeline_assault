package Level;

public enum SlopeProximityStatus {
    NONE, IN_SLOPE_LEFT, ON_TOP_OF_SLOPE_LEFT, IN_SLOPE_RIGHT, ON_TOP_OF_SLOPE_RIGHT
}
