package Level;

// This enum represents the potential states a level can be
public enum LevelState {
    RUNNING, LEVEL_COMPLETED, PLAYER_DEAD
}
