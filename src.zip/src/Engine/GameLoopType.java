package Engine;

public enum GameLoopType {
    POWER_SAVER, MAX_PERFORMANCE
}
